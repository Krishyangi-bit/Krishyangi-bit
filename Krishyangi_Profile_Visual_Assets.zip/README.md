<div align="center">

<img src="./galaxy-header.svg" width="100%" alt="Animated purple and pink galaxy header with KRISHYANGI" />

<h1>Hey, I'm Krishyangi 👋</h1>

<img src="./ascii-face-typing.gif" width="380" alt="Pink-purple ASCII face being typed in a terminal" />

<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&size=18&duration=2800&pause=800&color=D8B4FE&center=true&vCenter=true&width=700&height=36&lines=Turning+%22What+if%3F%22+into+working+software.;Teaching+machines+to+see+%E2%80%94+and+to+help.;Software+%2B+AI+%2B+hardware%2C+one+commit+at+a+time.;Debugger+by+necessity." alt="Typing introduction" />

<p>
  <img src="https://img.shields.io/github/followers/Krishyangi-bit?style=for-the-badge&label=FOLLOWERS&labelColor=1E1230&color=C026D3" alt="GitHub followers" />
  <a href="mailto:dixitkrishyangi@gmail.com"><img src="https://img.shields.io/badge/Email-C026D3?style=for-the-badge&logo=gmail&logoColor=white" alt="Email" /></a>
  <a href="https://www.linkedin.com/in/krishyangi-dixit-9527ba388/"><img src="https://img.shields.io/badge/LinkedIn-7C3AED?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn" /></a>
  <a href="https://github.com/Krishyangi-bit"><img src="https://img.shields.io/badge/GitHub-312044?style=for-the-badge&logo=github&logoColor=white" alt="GitHub" /></a>
</p>

<i>"Curious by default. Builder by choice. Debugger by necessity."</i>
</div>

---

<h2 align="center">Right Now</h2>

<table width="100%">
<tr><td width="50%" height="200" valign="top"><h4>🔭 Building</h4><b>NAVRAAH</b>: a wearable assistive-navigation prototype<br/><b>MindSpace</b>: student burnout prediction<br/><b>BugSift</b>: less time chasing bugs</td><td width="50%" height="200" valign="top"><h4>🌱 Learning</h4>Java, data structures &amp; algorithms, and how to make AI models run on small hardware</td></tr>
<tr><td height="100" valign="top"><h4>🤝 Looking for</h4>Internships, collaborations, and interesting problems worth losing sleep over</td><td height="100" valign="top"><h4>💬 Ask me about</h4>ANYTHING</td></tr>
</table>

<p align="center"><sub>⚡ Fun fact: my first hardware build taught me that one missing voltage divider can fry a Raspberry Pi. Now it's the first thing I check.</sub></p>

<details><summary><b>🔁 How I build things (click to expand)</b></summary>

```mermaid
flowchart LR
  A([💡 What if?]) --> B[🧪 Prototype]
  B --> C[💥 Break it]
  C --> D[🔍 Debug]
  D --> E[🚀 Ship]
  E --> F[📝 Document]
  F --> A
  style A fill:#7C3AED,stroke:#D8B4FE,color:#fff
  style C fill:#C026D3,stroke:#F0ABFC,color:#fff
  style E fill:#6D28D9,stroke:#D8B4FE,color:#fff
```
</details>

---

<h2 align="center">Tech Stack</h2>

<table align="center">
<tr><td align="right" valign="middle"><b>💻 Languages</b></td><td><img src="https://img.shields.io/badge/Python-1E1230?style=for-the-badge&logo=python&logoColor=D8B4FE" alt="Python" /> <img src="https://img.shields.io/badge/JavaScript-1E1230?style=for-the-badge&logo=javascript&logoColor=D8B4FE" alt="JavaScript" /> <img src="https://img.shields.io/badge/SQL-1E1230?style=for-the-badge&logo=mysql&logoColor=D8B4FE" alt="SQL" /> <img src="https://img.shields.io/badge/HTML5-1E1230?style=for-the-badge&logo=html5&logoColor=D8B4FE" alt="HTML5" /> <img src="https://img.shields.io/badge/CSS3-1E1230?style=for-the-badge&logo=css3&logoColor=D8B4FE" alt="CSS3" /></td></tr>
<tr><td align="right" valign="middle"><b>🌐 Frontend</b></td><td><img src="https://img.shields.io/badge/React-1E1230?style=for-the-badge&logo=react&logoColor=F0ABFC" alt="React" /> <img src="https://img.shields.io/badge/Figma-1E1230?style=for-the-badge&logo=figma&logoColor=F0ABFC" alt="Figma" /></td></tr>
<tr><td align="right" valign="middle"><b>⚙️ Backend</b></td><td><img src="https://img.shields.io/badge/Node.js-1E1230?style=for-the-badge&logo=nodedotjs&logoColor=E9D5FF" alt="Node.js" /> <img src="https://img.shields.io/badge/Flask-1E1230?style=for-the-badge&logo=flask&logoColor=E9D5FF" alt="Flask" /></td></tr>
<tr><td align="right" valign="middle"><b>📊 Data &amp; Vision</b></td><td><img src="https://img.shields.io/badge/NumPy-1E1230?style=for-the-badge&logo=numpy&logoColor=C084FC" alt="NumPy" /> <img src="https://img.shields.io/badge/Pandas-1E1230?style=for-the-badge&logo=pandas&logoColor=C084FC" alt="Pandas" /> <img src="https://img.shields.io/badge/OpenCV-1E1230?style=for-the-badge&logo=opencv&logoColor=C084FC" alt="OpenCV" /></td></tr>
<tr><td align="right" valign="middle"><b>🧰 Tools &amp; Hardware</b></td><td><img src="https://img.shields.io/badge/Git-1E1230?style=for-the-badge&logo=git&logoColor=F472B6" alt="Git" /> <img src="https://img.shields.io/badge/GitHub-1E1230?style=for-the-badge&logo=github&logoColor=F472B6" alt="GitHub" /> <img src="https://img.shields.io/badge/Vercel-1E1230?style=for-the-badge&logo=vercel&logoColor=F472B6" alt="Vercel" /> <img src="https://img.shields.io/badge/PowerShell-1E1230?style=for-the-badge&logo=powershell&logoColor=F472B6" alt="PowerShell" /> <img src="https://img.shields.io/badge/Raspberry_Pi-1E1230?style=for-the-badge&logo=raspberrypi&logoColor=F472B6" alt="Raspberry Pi" /></td></tr>
<tr><td align="right" valign="middle"><b>🌱 Learning</b></td><td><img src="https://img.shields.io/badge/Java-1E1230?style=for-the-badge&logo=openjdk&logoColor=D8B4FE" alt="Java" /> <img src="https://img.shields.io/badge/DSA-1E1230?style=for-the-badge" alt="DSA" /></td></tr>
</table>

### ✨ Floating Tech Particles
<p align="center"><img src="./tech-particles.svg" width="100%" alt="Floating purple and pink tech stack particles" /></p>

---

<h2 align="center">Featured Projects</h2>

<table width="100%">
<tr><td><h3>🧭 NAVRAAH</h3><i>Navigation Assistant For Visually Restricted And Aided Humans</i><br/><sub>Technology with a purpose. Independence through innovation.</sub><br/><br/>
<p><img src="https://img.shields.io/badge/Python-7C3AED?style=flat-square" alt="Python" /> <img src="https://img.shields.io/badge/YOLOv8-0F9D78?style=flat-square" alt="YOLOv8" /> <img src="https://img.shields.io/badge/ONNX-C026D3?style=flat-square" alt="ONNX" /> <img src="https://img.shields.io/badge/OpenCV-E5484D?style=flat-square" alt="OpenCV" /> <img src="https://img.shields.io/badge/Computer_Vision-D6336C?style=flat-square" alt="Computer Vision" /> <img src="https://img.shields.io/badge/Raspberry_Pi-D97706?style=flat-square" alt="Raspberry Pi" /> <img src="https://img.shields.io/badge/Hardware-475569?style=flat-square" alt="Hardware" /> <img src="https://img.shields.io/badge/Ultrasonic_Sensing-7C3AED?style=flat-square" alt="Ultrasonic Sensing" /> <img src="https://img.shields.io/badge/Haptic_Feedback-C026D3?style=flat-square" alt="Haptic Feedback" /> <img src="https://img.shields.io/badge/Audio_Output-6D28D9?style=flat-square" alt="Audio Output" /></p>
<ul><li>Wearable assistive prototype that applies <b>computer vision</b> (YOLOv8 exported to ONNX, OpenCV) to help visually restricted people understand their surroundings.</li><li>Measures obstacle distance with an <b>HC-SR04 ultrasonic sensor</b> on the Raspberry Pi's GPIO, using a voltage divider to protect the 3.3V pins.</li><li>Alerts the user through <b>haptic feedback</b> (transistor-driven vibration motor) and <b>audio output</b> (speaker with an amplifier).</li><li>Battery-powered and packed into a compact enclosure with only the camera exposed.</li></ul><a href="https://github.com/Krishyangi-bit?tab=repositories"><b>View repository →</b></a></td></tr>
<tr><td><h3>🧠 MindSpace</h3><i>Understanding student well-being through data and intelligence</i><br/><br/>
<p><img src="https://img.shields.io/badge/Python-7C3AED?style=flat-square" alt="Python" /> <img src="https://img.shields.io/badge/Flask-475569?style=flat-square" alt="Flask" /> <img src="https://img.shields.io/badge/NLP-C026D3?style=flat-square" alt="NLP" /> <img src="https://img.shields.io/badge/Sentiment_Analysis-0F9D78?style=flat-square" alt="Sentiment Analysis" /> <img src="https://img.shields.io/badge/Multimodal-D6336C?style=flat-square" alt="Multimodal" /> <img src="https://img.shields.io/badge/Web_Development-D97706?style=flat-square" alt="Web Development" /></p>
<ul><li>Intelligent <b>multimodal framework</b> that predicts student burnout.</li><li>Reads <b>temporal chat sentiment</b>, so it tracks how mood changes over time, not just a single snapshot.</li><li>Combines sentiment with <b>behavioral pattern analysis</b> for a fuller picture of well-being.</li><li>Built as a Python and Flask web application.</li></ul><a href="https://github.com/Krishyangi-bit?tab=repositories"><b>View repository →</b></a></td></tr>
<tr><td><h3>🐞 BugSift</h3><i>Less time chasing bugs. More time building better software.</i><br/><br/><p><img src="https://img.shields.io/badge/Debugging-C026D3?style=flat-square" alt="Debugging" /> <img src="https://img.shields.io/badge/Developer_Tools-7C3AED?style=flat-square" alt="Developer Tools" /></p><a href="https://github.com/Krishyangi-bit?tab=repositories"><b>View repository →</b></a></td></tr>
</table>

---

<h2 align="center">GitHub Presence</h2>
<table align="center"><tr><td align="center"><img height="165" src="https://github-readme-stats.vercel.app/api?username=Krishyangi-bit&show_icons=true&hide_border=true&bg_color=0B0618&title_color=D8B4FE&icon_color=F472B6&text_color=F3E8FF&border_radius=12" alt="GitHub statistics" /></td><td align="center"><img height="165" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Krishyangi-bit&layout=compact&hide_border=true&bg_color=0B0618&title_color=D8B4FE&text_color=F3E8FF&border_radius=12" alt="Most-used repository languages" /></td></tr></table>
<p align="center"><img src="https://streak-stats.demolab.com/?user=Krishyangi-bit&hide_border=true&background=0B0618&ring=D8B4FE&fire=F472B6&currStreakLabel=D8B4FE&currStreakNum=F3E8FF&sideNums=F3E8FF&sideLabels=C4B5FD&dates=C4B5FD&border_radius=12" alt="GitHub contribution streak" width="70%" /></p>
<p align="center"><img src="https://raw.githubusercontent.com/Krishyangi-bit/Krishyangi-bit/output/github-snake-dark.svg" alt="Animated GitHub contribution snake" width="100%" /></p>

---

<h2 align="center">Where This Is Going</h2>
- 🧱 Stronger foundations in software engineering and computer science
- ⚡ Practical AI-powered applications with thoughtful design
- 📐 Better design, documentation, testing, and explanation of everything I build
- 🌍 A portfolio that shows curiosity, technical depth, and real-world problem-solving

---

<div align="center">
<h2>Let's Connect</h2>
Always happy to connect with people who enjoy building, learning, and solving interesting problems.
<p><a href="mailto:dixitkrishyangi@gmail.com"><img src="https://img.shields.io/badge/Email-dixitkrishyangi%40gmail.com-C026D3?style=for-the-badge&logo=gmail&logoColor=white" alt="Email Krishyangi" /></a> <a href="https://www.linkedin.com/in/krishyangi-dixit-9527ba388/"><img src="https://img.shields.io/badge/LinkedIn-Connect-7C3AED?style=for-the-badge&logo=linkedin&logoColor=white" alt="Connect on LinkedIn" /></a></p>
<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&size=16&duration=3000&pause=1200&color=D8B4FE&center=true&vCenter=true&width=600&height=30&lines=Thanks+for+stopping+by.+Go+build+something.;It+works+on+my+machine.+%F0%9F%98%84" alt="Typing sign-off" />
<img src="https://capsule-render.vercel.app/api?type=waving&color=0:EC4899,50:6D28D9,100:0B0618&height=90&section=footer" width="100%" alt="Purple and pink footer banner" />
</div>
